package pe.autonoma.pokedexv2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import pe.autonoma.pokedexv2.models.PokemonDetalle;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;


public class PokemonDetalleActivity extends AppCompatActivity {
    TextView tvNombre,tvBase,tvAlto,tvPeso,tvTipo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pokemon_detalle);
        //
        tvNombre = findViewById(R.id.tvNombre);
        tvBase = findViewById(R.id.tvBase);
        tvAlto= findViewById(R.id.tvAlto);
        tvPeso = findViewById(R.id.tvPeso);
        tvTipo= findViewById(R.id.tvTipo);
        // retroit
        Retrofit retrofit = new PokemonAdapter().getAdapter();
        //instanciamos restClient
        PokemonApi pokemonAPI=retrofit.create(PokemonApi.class);
        //
        //cambiar ivysaur x getExtra
        Call<PokemonDetalle> pokemonDetalleCall =
                pokemonAPI.getPokemonDetalle("");

        tvNombre.setText("Nombre: " +
                getIntent().getExtras().getString("nombre"));

        tvBase.setText("Base: " +
                getIntent().getExtras().getString("base"));

        tvAlto.setText("Alto: " +
                getIntent().getExtras().getString("alto"));
        tvPeso.setText("Peso: " +
                getIntent().getExtras().getString("peso"));

        tvTipo.setText("Tipo: " +
                getIntent().getExtras().getString("tipo"));




        pokemonDetalleCall.enqueue(new Callback<PokemonDetalle>() {
            @Override
            public void onResponse(Call<PokemonDetalle> call, Response<PokemonDetalle> response) {
                tvNombre.setText("Nombre: " + response.body().getName() );
                tvBase.setText("Base: " + response.body().getBase_experience().toString() );
                tvAlto.setText("Alto: " + response.body().getHeight().toString() );
                tvPeso.setText("Peso: " + response.body().getWeight().toString() );
                tvTipo.setText("Tipo: " + response.body().getType() );
            }

            @Override
            public void onFailure(Call<PokemonDetalle> call, Throwable t) {

            }
        });


    }

}
