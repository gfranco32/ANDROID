package com.example.miprimeraapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.view.textservice.TextInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.google.android.material.textfield.TextInputLayout;

import org.w3c.dom.Text;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    EditText txtCorreo, txtPas;
    Button btnIngresar;
    TextInputLayout impCorreo,ImpPas;

    boolean cor=false,pas=false;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtCorreo=(EditText)findViewById(R.id.txtCorreo);
        txtPas=(EditText)findViewById(R.id.txtPassword);

        impCorreo=(TextInputLayout)findViewById(R.id.impCorreo);
        ImpPas=(TextInputLayout)findViewById(R.id.impPassword);

        btnIngresar=(Button)findViewById(R.id.btnIniciar);

        btnIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(Patterns.EMAIL_ADDRESS.matcher(txtCorreo.getText().toString()).matches()==false){
                   impCorreo.setError("Correo Invalido");
                   cor=false;
                } else{
                    cor=true;
                    impCorreo.setError(null);
                }

                Pattern p=Pattern.compile("[0-9][0-9][0-9][0-9][0-9]");
                if (p.matcher(txtPas.getText().toString()).matches()==false){
                    ImpPas.setError("Password Invalido");
                    pas=false;
                } else{
                    pas=true;
                    ImpPas.setError(null);
                }

                if(cor==true && pas==true){
                    String usu=txtCorreo.getText().toString();
                    String clave=txtPas.getText().toString();
                    if (usu.equals("usuario@Android.com")&&clave.equals("12345")){
                        Intent i=new Intent(getApplicationContext(),Principal.class);
                        startActivity(i);

                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Usuario o Pas Incorrectos"
                                , Toast.LENGTH_SHORT).show();
                    }
                }


            }

        });


    }
}
